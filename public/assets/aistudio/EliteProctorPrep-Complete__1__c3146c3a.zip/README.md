# EliteProctorPrep

> **Next-Generation NCLEX, USMLE & Clinical Nursing Licensure Exam Preparation Platform**

EliteProctorPrep is a production-grade clinical examination preparation application designed for nursing and medical students preparing for high-stakes board licensure exams:

- **NCLEX-RN®** (Next-Generation NCSBN Clinical Judgment Model, Case Studies, CAT Mock Tests)
- **NCLEX-PN®** (Practical Nursing, Delegation, Coordinated Care & Scope)
- **USMLE Step 1** (Basic Clinical Sciences, Pathology, Pharmacology, Physiology, Microbiology)
- **USMLE Step 2 CK** (Clinical Knowledge, Internal Medicine, Surgery, Pediatrics, Ob/Gyn)
- **ATI Comprehensive Predictor & TEAS 7**
- **HESI Exit Exam & HESI A2**

---

## Key Features

1. **Computer-Adaptive & Diagnostic Question Banks**: Real-time scoring, item discrimination, clinical rationales, and "Why others get this wrong" distractor breakdowns.
2. **Next-Gen NCLEX (NGN) Case Study Simulator**: 6-question unfolding clinical scenarios based on the NCSBN Clinical Judgment Measurement Model (CJMM).
3. **Pass Readiness Predictor**: Algorithmic benchmark predictor calculating predictive board pass probabilities based on practice velocity, accuracy, and study streaks.
4. **Resend Email Integration**: Automated dispatch of verified clinical score reports, pass readiness certificates, and study recommendations directly to candidate inboxes.
5. **Clerk Authentication**: Seamless, secure candidate sign-up, sign-in, user profiles, and session persistence.
6. **Neon Serverless PostgreSQL Database**: Server-side storage for candidate records, quiz attempts, NGN case outcomes, and email dispatch logs.
7. **Interactive Pharmacology Quick-Drill**: High-yield antidotes, cardiac meds, psychotropics, and medication safety flashcards.

---

## Tech Stack

- **Frontend**: React 19, TypeScript, Vite, Tailwind CSS v4, Lucide React, Motion
- **Authentication**: Clerk React SDK (`@clerk/clerk-react`)
- **Database**: Neon Serverless PostgreSQL (`@neondatabase/serverless`)
- **Email Dispatch**: Resend SDK (`resend`) with Vercel Serverless Functions (`/api/send-email.ts`)
- **Hosting & CI/CD**: Vercel

---

## Quick Start (Local Development)

### 1. Clone & Install Dependencies
```bash
git clone https://github.com/nexusexpertflow-oss/EliteProctorPrep.git
cd EliteProctorPrep
npm install
```

### 2. Configure Environment Variables
Copy the `.env.example` template:
```bash
cp .env.example .env.local
```

Fill in your configuration:
```env
# Clerk Authentication (Client-side)
VITE_CLERK_PUBLISHABLE_KEY="pk_test_..."

# Neon PostgreSQL Database (Server-side)
DATABASE_URL="postgresql://user:password@ep-example.us-east-2.aws.neon.tech/eliteproctorprep?sslmode=require"

# Resend Email Service (Server-side)
RESEND_API_KEY="re_..."
RESEND_FROM_EMAIL="EliteProctorPrep <onboarding@resend.dev>"
```

### 3. Run Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### 4. Build for Production
```bash
npm run build
```

### 5. Type-Check & Lint
```bash
npm run lint
```

---

## Database Setup (Neon PostgreSQL)

1. Open your [Neon Console](https://console.neon.tech) and create a project named `eliteproctorprep`.
2. Go to the **SQL Editor** tab in Neon.
3. Open `src/db/schema.sql` from this repository, copy its contents, and execute:
   - Creates `candidates` table (synced with Clerk User IDs)
   - Creates `quiz_attempts` table (practice exam test logs)
   - Creates `ngn_case_results` table (clinical case outcomes)
   - Creates `readiness_evaluations` table (pass probability benchmark records)
   - Creates `email_reports` table (Resend email delivery tracking)
4. Copy your Neon connection string into `DATABASE_URL`.

---

## Vercel Deployment Guide

### Option A: One-Click GitHub Import (Recommended)

1. Push this repository to your GitHub account (`nexusexpertflow-oss/EliteProctorPrep`).
2. Log in to [Vercel](https://vercel.com) and click **"Add New..." > "Project"**.
3. Select your repository `EliteProctorPrep`.
4. In **Project Settings**:
   - Framework Preset: **Vite**
   - Root Directory: `./`
   - Build Command: `npm run build`
   - Output Directory: `dist`
5. In **Environment Variables**, add:
   - `VITE_CLERK_PUBLISHABLE_KEY` = your Clerk publishable key
   - `DATABASE_URL` = your Neon connection string (Server-side only)
   - `RESEND_API_KEY` = your Resend API key (Server-side only)
   - `RESEND_FROM_EMAIL` = your verified sender email address
6. Click **Deploy**. Vercel will build the frontend and deploy the `/api/send-email` serverless function.

### Option B: Vercel CLI
```bash
npm install -g vercel
vercel login
vercel
vercel --prod
```

---

## Project Structure

```
├── api/
│   └── send-email.ts              # Vercel serverless function for Resend email dispatch
├── public/
│   ├── favicon.svg
│   └── EliteProctorPrep-Complete.zip # Downloadable complete project bundle
├── src/
│   ├── App.tsx                    # Main app container and routing
│   ├── main.tsx                   # React root entry point
│   ├── index.css                  # Global styles & Tailwind CSS
│   ├── components/
│   │   ├── Header.tsx             # Navigation header
│   │   ├── Hero.tsx               # Hero banner & primary CTA
│   │   ├── ExamLibrary.tsx        # Track browser (NCLEX-RN, NCLEX-PN, USMLE, etc.)
│   │   ├── QuizModal.tsx          # Interactive question practice with rationales & email button
│   │   ├── EmailReportModal.tsx   # Score report email dispatch & HTML preview
│   │   ├── ReadinessCalculator.tsx# Pass probability algorithm & email button
│   │   ├── StudentDashboardModal.tsx# Candidate portal & exam track switcher
│   │   ├── NgnCaseSimulator.tsx   # Next-Gen unfolding case studies
│   │   ├── PharmaDrillModal.tsx   # Pharmacology flashcards
│   │   ├── AuthModals.tsx         # Clerk authentication modals
│   │   └── ...
│   ├── data/
│   │   └── examsData.ts           # Exam tracks, subjects, and clinical practice items
│   ├── db/
│   │   ├── schema.sql             # Neon PostgreSQL table definitions and indexes
│   │   └── neon.ts                # Neon serverless client and database helpers
│   └── services/
│       └── resendService.ts       # Resend email API client & template generator
├── .env.example                   # Sanitized configuration template
├── package.json                   # Dependencies manifests and build scripts
├── tsconfig.json                  # TypeScript compiler settings
├── vercel.json                    # Vercel deployment rewrites & build configuration
└── vite.config.ts                 # Vite build and plugin configurations
```

---

## Security & Compliance Note

- All sensitive keys (`DATABASE_URL`, `RESEND_API_KEY`) remain strictly server-side.
- The client bundle only exposes `VITE_CLERK_PUBLISHABLE_KEY`, which is intended for public browser consumption.
- Zero secrets or passwords are included in the repository or git history.
